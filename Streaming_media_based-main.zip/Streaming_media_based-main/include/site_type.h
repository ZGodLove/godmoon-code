#ifndef SITE_TYPE_H_
#define SITE_TYPE_H_

#include <stdint.h>

typedef uint8_t chnid_t;

#endif