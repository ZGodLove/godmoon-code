#ifndef THR_LIST_H_
#define THR_LIST_H

#include "medialib.h"

int thr_list_create(struct mlib_listentry_st *, int);

int thr_list_destroy();

#endif